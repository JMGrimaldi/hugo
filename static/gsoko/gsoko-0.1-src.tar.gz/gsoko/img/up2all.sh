#! /bin/sh
# make all the pictures from the 'up' direction

for i in {"","1","2"}
do
	convert -rotate 90 up$i.xpm right$i.xpm
	convert -rotate 180 up$i.xpm down$i.xpm
	convert -rotate 270 up$i.xpm left$i.xpm

	convert -rotate 90 pup$i.xpm pright$i.xpm
	convert -rotate 180 pup$i.xpm pdown$i.xpm
	convert -rotate 270 pup$i.xpm pleft$i.xpm
done

