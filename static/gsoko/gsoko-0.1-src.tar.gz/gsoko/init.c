/*****************************************************************************
 * gsoko/init.c : globals initialization
 *****************************************************************************
 * Copyright (C) 2000 Jean-Michel Grimaldi
 *
 * Author: Jean-Michel Grimaldi <jm@via.ecp.fr>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *****************************************************************************/

#include "gsoko.h"

/* load the pixmaps */
void load_pixmaps(void)
{
	/* macro: i = direction index; name = direction name */
	#define load_pxm(a, i, name)	\
		a##_pxm[i][0][0] = gdk_pixmap_create_from_xpm(darea->window, &a##_pxm[i][0][1], NULL, "img/" #name ".xpm" );	\
		a##_pxm[i][1][0] = gdk_pixmap_create_from_xpm(darea->window, &a##_pxm[i][1][1], NULL, "img/" #name "1.xpm" );	\
		a##_pxm[i][2][0] = gdk_pixmap_create_from_xpm(darea->window, &a##_pxm[i][2][1], NULL, "img/" #name "2.xpm" );	\
		a##_pxm[i][3][0] = a##_pxm[i][1][0];	\
		a##_pxm[i][3][1] = a##_pxm[i][1][1];	\
		a##_pxm[i][4][0] = a##_pxm[i][2][0];	\
		a##_pxm[i][4][1] = a##_pxm[i][2][1];


	load_pxm(s, 1, left);
	load_pxm(s, 2, right);
	load_pxm(s, 3, up);
	load_pxm(s, 4, down);

	load_pxm(ps, 1, pleft);
	load_pxm(ps, 2, pright);
	load_pxm(ps, 3, pup);
	load_pxm(ps, 4, pdown);
	
	wall_pxm = gdk_pixmap_create_from_xpm(darea->window, NULL, NULL, "img/wall.xpm" );
	tile_pxm = gdk_pixmap_create_from_xpm(darea->window, NULL, NULL, "img/tile.xpm" );
	tile2_pxm = gdk_pixmap_create_from_xpm(darea->window, NULL, NULL, "img/tile2.xpm" );
	box_pxm = gdk_pixmap_create_from_xpm(darea->window, NULL, NULL, "img/box.xpm" );
	box2_pxm = gdk_pixmap_create_from_xpm(darea->window, NULL, NULL, "img/box2.xpm" );
}

/* initialize globals */
void init_var(void)
{
	/* initialize the backing pixmap */
	darea_pxm = gdk_pixmap_new(
		darea->window,
		darea->allocation.width,
		darea->allocation.height,
		-1);

	/* attach the Graphics Context */
	darea_gc = gdk_gc_new (darea_pxm);

	/* initialize level data, character data, and let the show begin! */
	new_game();
}

