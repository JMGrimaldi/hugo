<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Modifiez cette variable pour personnaliser l'affichage de dcComback::display()
$comback_display_str = '
	<p id="c0$comment_id" class="comment-info">R&eacute;ponse de <strong>$comback_author</strong> le $comback_date &agrave; $comback_time</p>
	<blockquote class="comback_content">
	$comback_content
	</blockquote>
';

?>
