<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Ce fichier est adapt� du rss.php de DotClear 1.2.4

# Chemin vers la racine de l'application (si vous changer le fichier de place)
$app_path = '/../../../';

# Nombre d'entr�es publi�es dans le fil
$limit = 20;

# Si par exemple vous mettez rss.php � la racine de votre site et que DotClear
# se trouve dans /dotclear vous pouvez d�commenter cette ligne :
//$app_path = '/dotclear/';

# NE RIEN CHANGER APRES CETTE LIGNE

$blog_dc_path = dirname(__FILE__).$app_path;

require $blog_dc_path.'/inc/prepend.php';
require $blog_dc_path.'/layout/lib.cache.php';

require $blog_dc_path.'/layout/class.xblog.php';
require $blog_dc_path.'/layout/class.xblogpost.php';
require $blog_dc_path.'/layout/class.xblogcomment.php';

$type = $_GET['type'];
$post = $_GET['post'];

# Cache HTTP
if (dc_http_cache && defined('DC_UPDATE_FILE_W') && DC_UPDATE_FILE_W)
{
	$mod_files = get_included_files();
	$mod_files[] = DC_UPDATE_FILE;
	$mod_files[] = $blog_dc_path.'/conf/dotclear.ini';

	cache::http($mod_files);
}

# Connexion MySQL
$con = new Connection(DB_USER,DB_PASS,DB_HOST,DB_DBASE);

if ($con->error()) { exit; }

# Cr�ation de l'objet de type weblog avec uniquement les billets
# publi�s
$blog = new xblog($con,DB_PREFIX,1,dc_encoding);
$blog->rs_blogpost = 'xblogpost';
$blog->rs_blogcomment = 'xblogcomment';

$blog->setURL('post',util::getHost().dc_blog_url.dc_format_post_url);

# Si type = cb on fait un fil des commentaires & combacks
if ($type == 'cb') {
	# Si 'post' est vide on fait le fil des comms et combacks de tout le blog
	$reqPlus = empty($post) ? '' : "AND p.post_id=$post";

	# R�cup�ration des combacks et des commentaires
	#---
	# On renomme les champs de dc_comback avec le nom de ceux de dc_comments afin
	# de pouvoir utiliser les m�thodes de la classe xblogcomment
	$t_comback = DB_PREFIX.'comback';
	$t_comment = $blog->t_comment;
	$t_post = $blog->t_post;
	$t_user = $blog->t_user;

	$strReq = <<<EOT
	SELECT CONCAT('0', c.comment_id) comment_id, cb.comback_dt comment_dt, cb.comback_content comment_content,
		IF(LENGTH(user_pseudo), user_pseudo, CONCAT(user_prenom, ' ', user_nom)) comment_auteur, post_titre, post_titre_url, p.post_id,
		DATE_FORMAT(post_dt,'%d') postday,
		DATE_FORMAT(post_dt,'%m') postmonth,
		DATE_FORMAT(post_dt,'%Y') postyear
	FROM $t_comback cb, $t_comment c, $t_post p, $t_user u
	WHERE cb.user_id = u.user_id
	AND cb.comment_id=c.comment_id AND c.post_id=p.post_id
	$reqPlus
UNION
	SELECT comment_id, comment_dt, comment_content,
		comment_auteur, p.post_titre, p.post_titre_url, p.post_id,
		DATE_FORMAT(p.post_dt,'%d') postday,
		DATE_FORMAT(p.post_dt,'%m') postmonth,
		DATE_FORMAT(p.post_dt,'%Y') postyear
	FROM $t_comment C, $t_post p
	WHERE comment_trackback <> 1
	AND p.post_id = C.post_id
	$reqPlus
ORDER BY comment_dt DESC LIMIT $limit
EOT;
	$comments = $blog->con->select($strReq,$blog->rs_blogcomment);
	if ($comments)
		$comments->setBlog($blog);
	#---
	
	$title = dc_blog_name.' - Commentaires &amp; r&eacute;ponses';
	$ts = time();
	$items = $seq = '';
	
	if (!$comments->isEmpty())
	{
		$ts = $comments->getTS();
		
		while(!$comments->EOF()) {
		# On parcourt les commentaires
			# On met le comm dans le fil
			$seq .= $comments->getRSSSeq();
			$items .= $comments->getRSSItem(dc_short_feeds);
			$comments->moveNext();
		}
	}
}

# Fermeture de connexion
$con->close();

header('Content-Type: application/rss+xml; charset='.dc_encoding);
echo '<?xml version="1.0" encoding="'.dc_encoding.'" ?>'."\n";
?>
<rdf:RDF
  xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
  xmlns:admin="http://webns.net/mvcb/"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns="http://purl.org/rss/1.0/">

<channel rdf:about="<?php echo util::getHost().dc_blog_url; ?>">
  <title><?php echo $blog->toXML($title); ?></title>
  <description><![CDATA[<?php echo dc_blog_desc; ?>]]></description>
  <link><?php echo util::getHost().dc_blog_url; ?></link>
  <dc:language><?php echo DC_LANG; ?></dc:language>
  <dc:creator></dc:creator>
  <dc:rights></dc:rights>
  <dc:date><?php echo dt::iso8601($ts); ?></dc:date>
  <admin:generatorAgent rdf:resource="http://www.dotclear.net/" />
  
  <sy:updatePeriod>daily</sy:updatePeriod>
  <sy:updateFrequency>1</sy:updateFrequency>
  <sy:updateBase><?php echo dt::iso8601($ts); ?></sy:updateBase>
  
  <items>
  <rdf:Seq>
  <?php echo $seq; ?>
  </rdf:Seq>
  </items>
</channel>

<?php echo $items; ?>

</rdf:RDF>
