<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Classe de gestion des 'combacks' (r�ponses aux commentaires)
require dirname(__FILE__).'/class.comback.php';
$comback_url = 'tools.php?p=comback';
$ecrire_path = dirname(__FILE__).'/../..';

# Choix de la page de l'interface : liste, �dition, aide, ...
$page = !empty($_REQUEST['page']) ? $_REQUEST['page'] : NULL;

# Barre de titre
$mySubMenu->addItem('ComBack', $comback_url, 0, 0);
$mySubMenu->addItem('?', "$comback_url&amp;page=help", 0, $page == 'help');

$comback = new comback($blog, DB_PREFIX);
$comback->install();	# Installation : cr�ation de la table des combacks si besoin

$err = '';

# Affichage des erreurs �ventuelles
function showErr($err)
{
	if ($err != '') {
		buffer::str(
		'<div class="erreur"><p><strong>'.__('Error(s)').' :</strong></p>'.
		'<p>'.$err.'</p>'.
		'</div>');
	}
}

# Aiguillage en fonction de la page demand�e
if ($page == 'help') {
	# �cran d'aide
	require dirname(__FILE__).'/help.php';
	showErr($err);
}
elseif ($page == 'edit' && !empty($_REQUEST['comment_id'])) {
	# �dition d'un comback
	require dirname(__FILE__).'/edit.php';
	showErr($err);
}
else {
	# Ajout/modif d'un comback
	if (!empty($_POST['save'])) {
		$com_id = $_POST['comment_id'];
		$user_id = $_SESSION['sess_user_id'];
		$content = trim($_POST['comback_content']);

		$comback->saveComback($com_id, $user_id, $content);
	}
	
	# Suppression d'un comback
	if (!empty($_POST['delete'])) {
		$com_id = $_POST['comment_id'];

		$comback->delComback($com_id);
	}

	# Affichage
	#---
	showErr($err);
	
	# Liste des commentaires
	require dirname(__FILE__).'/comments.php';
}

?>
