<div id="gallery_header_container">
<!-- #### START HEADER CONTENT #### -->
	
	<h1>MINISHOWCASE HEADER</h1>
	
<!-- #### END HEADER CONTENT #### -->
</div>