<div id="gallery_footer_container">
<!-- #### START FOOTER CONTENT #### -->
	
	<p>MINISHOWCASE FOOTER</p>
	
<!-- #### END FOOTER CONTENT #### -->
</div>