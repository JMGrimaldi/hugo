JMparse 1.0 - Documentation
----------------------------

*** SCRIPT ***
'jmparse.php3' is a php3 script that generates pages with a common layout.
This common layout is described in 'template.txt', located in the same dir as the script, which is an HTML document with some special tags :
> $name$ : file name without the extension
> $rpath$  : path of the root directory where, for example, style sheets can be stored
> $img$    : path of the images dir (this dir may contain a logo)
> $title$  : $pretitle string, then name of upper dirs, and name of current page
> $btitle$ : name of upper dirs, linked to these, '/'-separated, and name of current page
> $menu$   : site tree (see it to understand)
> $content$: content of the '.jm' file associated to the page

Each directory must contain an 'index.txt' file describing the pages in this dir : first the name ('glop' for 'glop.html'), then the title ('Glop club'). The content of 'glop.html' will be copied from 'glop.jm'. If you want to make subdirectories, just make a new directory named 'glop' in our example, and put an 'index.txt' and some '.jm' files in it.

*** PARAMETERS ***
'param.txt' contains some definitions :
> $rdir    : site root path from parser directory ('../' if the script is in a simple subdir)
> $imgdir  : images dir from site root
> $pretitle: string added to the beginning of each page title
> $ext     : extension of generated files ('.htm', '.html', '.php3', ...)
> $count   : TRUE/FALSE -> manages php3 counters = creates .cnt files and adds .php code to each file
> $ti      : main page title

*** TO-DO ***
Future versions should bring :
- better customization (especially for the menu)
- web interface (with secure authentification)
- more $...$ tags
- menu items with different styles in different depths
- multilingual support
- menu separators support
- package with other scripts for webmasters (thumbnails, site map...)

*** LICENSE ***
All rights reserved by JM Grimaldi
You can use and modify this script as long as you keep this copyright with it.

*** DISCLAIMER ***
Note that you are using the script and the accompanying files on your own risk. I cannot be held responsible, explicitly or even implicitly, for eventual side-effects, including, but not limiting to, loss of money or property, loss of humanity or death itself.

--
Feb 16, 2000
Jean-Michel Grimaldi
(jm@via.ecp.fr)
