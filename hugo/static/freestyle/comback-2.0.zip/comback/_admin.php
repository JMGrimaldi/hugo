<?php
# ComBack for DotClear
# (c)2006-2009 Jihem

if (!defined('DC_CONTEXT_ADMIN')) { return; }

# D�claration de la page d'aide
if (!isset($__resources['help']['comback'])) {
	        $__resources['help']['comback'] = dirname(__FILE__).__('/help.html');
}

# Inscription dans le menu de l'interface d'admin
$_menu['Plugins']->addItem('ComBack','plugin.php?p=comback','index.php?pf=comback/icon.png',
	preg_match('/plugin.php\?p=comback/',$_SERVER['REQUEST_URI']),
	$core->auth->check('usage,contentadmin',$core->blog->id));
?>
