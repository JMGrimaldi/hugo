<?php
# ComBack for DotClear
# (c)2006-2009 Jihem
#--
# Page principale de l'extension

if (!defined('DC_CONTEXT_ADMIN')) { exit; }
dcPage::check('usage,contentadmin');

$comback_url = 'plugin.php?p=comback';
$comback = new comback($core);
$comback->install();	# Installation : cr�ation de la table des combacks si besoin
?>
<html>
<head>
	<title>ComBack</title>
	<style><?php include dirname(__FILE__).'/comback.css';?></style>
</head>

<body>
<h2><?php
echo html::escapeHTML($core->blog->name).' &gt; <a href="'.$comback_url.'">ComBack</a></h2>';

$action = !empty($_REQUEST['action']) ? $_REQUEST['action'] : NULL;
if ($action == 'about') {
	$default_tab = 'tab-about';
}
elseif ($action == 'edit' && !empty($_REQUEST['id'])) {
	$default_tab = 'tab-edit';
	include dirname(__FILE__).'/edit.php';
}
else {
	# Ajout/modif d'un comback
	if (!empty($_POST['save'])) {
		$com_id = $_POST['id'];
		$user_id = $core->auth->userID();

		$content = trim($_POST['comment_content']);

		# L'�diteur js met toujours un <p>
		if (!strcmp($content, '<p></p>')) {$content = '';}

		$comback->saveComback($com_id, $user_id, $content);
	}

	# Suppression d'un comback
	if (!empty($_POST['del'])) {
		$com_id = $_POST['id'];

		$comback->delComback($com_id);
	}

	$default_tab = 'tab-comments';
	include dirname(__FILE__).'/comments.php';
}
include dirname(__FILE__).'/about.php';

echo dcPage::jsPageTabs($default_tab);
dcPage::helpBlock('comback');
?>
</body>
</html>
