<?php
# ComBack for DotClear
# (c)2006-2009 Jihem
#--
# Fonctions accessibles depuis le blog

if (!defined('DC_RC_PATH')) { return; }

$core->tpl->addValue('CombackContent', array('dcComback', 'CombackContent'));
$core->tpl->addValue('PostNbCombacks', array('dcComback', 'PostNbCombacks'));

# Fonctions c�t� blog
class dcComback
{
	# Affichage du nombre de combacks
	#---
	# Les 3 premiers arguments permettent de d�finir le texte affich�
        # pour respectivement aucun, un, ou plusieurs commentaires.
	# Le 4e argument est affich� devant le nombre de combacks si la
	# cha�ne n'est pas vide
	function PostNbCombacks($attr)
	{
		global $core;

		# S'il s'agit de l'appel par {{tpl:PostNbCombacks}}
		if (!$attr['callback'])
		{
			$params = '$params=array("callback"=>1,"post_id"=>$_ctx->posts->post_id);';
			foreach($attr as $k=>$v) {
				$params .= '$params["'.$k.'"] = "'.$v.'";';
			}
			return '<?php '.$params.'$cb = new dcComback; echo $cb->PostNbCombacks($params); ?>';
		}

		# S'il s'agit du callback positionn� ci-dessus
		$post_id = $attr['post_id'];
		$none = $attr['none'];
		$one = $attr['one'];
		$more = $attr['more'];
		$prefix = $attr['prefix'];

		$t_comment = $core->prefix.'comment';
		$t_comback = $core->prefix.'comback';

		$strReq = "select count(*)
			from $t_comback cb, $t_comment c
			where cb.comment_id=c.comment_id and c.post_id='$post_id'";

		# R�cup�ration
		if (!($cb = $core->con->select($strReq)))
			return false;
		$nb = $cb->f(0);
		
		# Formatage
		if($nb == 0)
			$str = $none;
		elseif($nb == 1)
			$str = $one;
		else
			$str = sprintf($more,$nb);
		if (!$str)
			return '';
		$str = "$prefix<span class=\"nb_combacks\">$str</span>";

		# Affichage
		return $str;
	}
	
	# Affichage d'un comback
	static public function CombackContent($attr)
	{
		global $core;

		require dirname(__FILE__).'/config.php';
	
		# S'il s'agit de l'appel par {{tpl:CombackContent}}
		if (!$attr['callback'])
		{
			$params = '$params=array("callback"=>1,"comment_id"=>$_ctx->comments->comment_id);';
/*			return '<?php '.$params.' echo $params["comment_id"]; ?>';*/
			return '<?php '.$params.' $cb = new dcComback; echo $cb->CombackContent($params); ?>';
		}

		# S'il s'agit du callback positionn� ci-dessus
		$comment_id = $attr['comment_id'];
		$t_comback = $core->prefix.'comback';
	
		
		$strReq = "select cb.comback_dt, cb.comback_content,
			u.user_displayname user_pseudo, u.user_firstname user_prenom, u.user_name user_nom
			from $t_comback cb, {$core->prefix}user u
			where cb.comment_id = $comment_id and cb.user_id = u.user_id";

		# R�cup�ration
		if (!($cb = $core->con->select($strReq)))
			return false;
		if($cb->isEmpty())
			return '';

		# Formatage
		$ts = strtotime($cb->f('comback_dt'));
		$comback_date = dt::str($core->blog->settings->date_format, $ts);
		$comback_time = dt::str($core->blog->settings->time_format, $ts);
		$comback_author = ($cb->f('user_pseudo') != '' ?
	       		$cb->f('user_pseudo') :
			$cb->f('user_prenom').' '.$cb->f('user_nom')
		);
		$comback_content = $cb->f('comback_content');

		# Affichage
		return eval('echo <<<EOT
'.$comback_display_str.'
EOT
;');
	}
}
	
?>
