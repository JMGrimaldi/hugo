<?php
# ComBack for DotClear
# (c)2006-2009 Jihem
#--
# Onglet d'�dition d'un comback

echo '<div class="multi-part" id="tab-edit" title="'.__('Reply').'">';

# Adapt� de admin/comment.php
#----------
$comment_id = null;
$comment_dt = '';
$comment_author = '';
$comment_email = '';
$comment_site = '';
$comment_content = '';
$comment_ip = '';
$comment_status = '';
$comment_trackback = 0;
$comment_spam_status = '';
$comback_content = '';

if (!empty($_REQUEST['id']))
{
	$params['comment_id'] = $_REQUEST['id'];
	
	try {
		$rs = $core->blog->getComments($params);
		if (!$rs->isEmpty()) {
			$comment_id = $rs->comment_id;
			$post_id = $rs->post_id;
			$post_type = $rs->post_type;
			$post_title = $rs->post_title;
			$comment_dt = $rs->comment_dt;
			$comment_author = $rs->comment_author;
			$comment_email = $rs->comment_email;
			$comment_site = $rs->comment_site;
			$comment_content = $rs->comment_content;
			$comment_ip = $rs->comment_ip;
			$comment_status = $rs->comment_status;
			$comment_trackback = (boolean) $rs->comment_trackback;
			$comment_spam_status = $rs->comment_spam_status;
		}
	} catch (Exception $e) {
		$core->error->add($e->getMessage());
	}
}

if (!$comment_id && !$core->error->flag()) {
	$core->error->add(__('No comment'));
}

# R�cup�ration de la r�ponse �ventuellement existante
if ($cb = $comback->getComback($comment_id)) {
	$comback_content = $cb->f('comback_content');
	$comback_user = $cb->f('user_id');
}

if (!$core->error->flag() && isset($rs))
{
	# Un admin peut tout faire
	$can_edit = $can_delete = true;

	# Un simple r�dacteur ne peut pas modifier le comback laiss� par quelqu'un d'autre
	if ($cb && !$core->auth->check('contentadmin',$core->blog->id) && $core->auth->userID() != $comback_user) {
		$can_edit = $can_delete = false;
	}
	
	if (!$can_edit) {
		$core->error->add(__("You can't edit this reply."));
	}
}

/* DISPLAY
-------------------------------------------------------- */
echo	dcPage::jsConfirmClose('comment-form').
	dcPage::jsToolBar().
	dcPage::jsLoad('js/_comment.js');

if ($comment_id)
{
	$comment_mailto = '';
	if ($comment_email)
	{
		$comment_mailto = '<a href="mailto:'.html::escapeHTML($comment_email)
		.'?subject='.rawurlencode(sprintf(__('Your comment on my blog %s'),$core->blog->name))
		.'&body='
		.rawurlencode(sprintf(__("Hi!\n\nYou wrote a comment on:\n%s\n\n\n"),$rs->getPostURL()))
		.'">'.$comment_email.'</a>';
	}
	
	echo '<p><a class="back" href="'.$core->getPostAdminURL($post_type,$post_id).'&amp;co=1#c'.$comment_id.'"> '.$post_title.'</a></p>';
	
	echo
	'<form action="'.$comback_url.'" method="post" id="comment-form">'.
	'<p>'.
	__('IP address:').' <a href="comments.php?ip='.$comment_ip.'">'.$comment_ip.'</a><br />'.
	__('Date:').' '.dt::dt2str(__('%Y-%m-%d %H:%M'),$comment_dt).'<br />'.
	__('Author:').' '.$comment_author.'<br />'.
	__('Email:').' '.$comment_mailto.'<br />'.
	__('Web site:').' '.$comment_site.'</p>'.
	
	# --BEHAVIOR-- adminAfterCommentDesc
	$core->callBehavior('adminAfterCommentDesc', $rs).

	'<p style="margin: 1em 0 0 0">'.__('Comment:').' '.
	'<div style="border: 1px solid #999; padding: 1em 10px; margin-bottom: 1em">'.$comment_content.'</div>'.
	'</p>'.
	
	# On garde l'id "comment_content" pour avoir la bare d'�dition de _comment.js
	'<p class="area"><label for="comment_content">'.__('Reply:').'</label> '.
	form::textarea('comment_content',50,5,html::escapeHTML($comback_content)).	# XXX Hauteur modifiée
	'</p>'.
	
	'<p>'.form::hidden('id',$comment_id).
	$core->formNonce().
	'<input type="submit" accesskey="s" name="save" value="'.__('save').'" /> ';
	
	if ($can_delete) {
	# On ne garde pas le nom "delete" pour �viter le msg de confirmation
		echo '<input type="submit" name="del" value="'.__('delete').'" />';
	}
	echo
	'</p>'.
	'</form>';
}

echo '</div>';
?>
