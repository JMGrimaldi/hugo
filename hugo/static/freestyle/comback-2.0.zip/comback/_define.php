<?php
if (!defined('DC_RC_PATH')) { return; }

$this->registerModule(
	/* Name */			"ComBack",
	/* Description*/		"Reply to comments",
	/* Author */			"Jihem",
	/* Version */			'2.0',
	/* Permissions */		'usage,contentadmin'
);
?>
