<?php
# ComBack for DotClear
# (c)2006-2009 Jihem
# Classe pour l'affichage de la liste de commentaires dans l'admin

# Tir� de inc/admin/lib.pager.php
#----
class combackList extends adminCommentList
{
	public function display($page,$nb_per_page,$enclose_block='')
	{
		if ($this->rs->isEmpty())
		{
			echo '<p><strong>'.__('No comment').'</strong></p>';
		}
		else
		{
			$pager = new pager($page,$this->rs_count,$nb_per_page,10);
			$pager->html_prev = $this->html_prev;
			$pager->html_next = $this->html_next;
			$pager->var_page = 'page';
			
			$html_block =
			'<table><tr>'.
			'<th colspan="2">'.__('Title').'</th>'.
			'<th>'.__('Date').'</th>'.
			'<th>'.__('Author').'</th>'.
			'<th>'.__('Type').'</th>'.
			'<th>'.__('Status').'</th>'.
			'<th>&nbsp;</th>'.
			'</tr>%s</table>';
			
			if ($enclose_block) {
				$html_block = sprintf($enclose_block,$html_block);
			}
			
			echo '<p>'.__('Page(s)').' : '.$pager->getLinks().'</p>';

			$blocks = explode('%s',$html_block);
			
			echo $blocks[0];
			
			while ($this->rs->fetch())
			{
				echo $this->commentLine();
			}
			
			echo $blocks[1];
			
			echo '<p>'.__('Page(s)').' : '.$pager->getLinks().'</p>';
		}
	}
	
	private function commentLine()
	{
		global $author, $status, $sortby, $order, $nb_per_page;
		
		$author_url =
		'comments.php?n='.$nb_per_page.
		'&amp;status='.$status.
		'&amp;sortby='.$sortby.
		'&amp;order='.$order.
		'&amp;author='.rawurlencode($this->rs->comment_author);
		
		$post_url = $this->core->getPostAdminURL($this->rs->post_type,$this->rs->post_id);
		
		$comment_url = 'comment.php?id='.$this->rs->comment_id;
		
		$comment_dt =
		dt::dt2str($this->core->blog->settings->date_format.' - '.
		$this->core->blog->settings->time_format,$this->rs->comment_dt);
		
		$img = '<img alt="%1$s" title="%1$s" src="images/%2$s" />';
		switch ($this->rs->comment_status) {
			case 1:
				$img_status = sprintf($img,__('published'),'check-on.png');
				break;
			case 0:
				$img_status = sprintf($img,__('unpublished'),'check-off.png');
				break;
			case -1:
				$img_status = sprintf($img,__('pending'),'check-wrn.png');
				break;
			case -2:
				$img_status = sprintf($img,__('junk'),'junk.png');
				break;
		}
		
		$comment_author = html::escapeHTML($this->rs->comment_author);
		if (mb_strlen($comment_author) > 20) {
			$comment_author = mb_strcut($comment_author,0,17).'...';
		}

		# XXX Ajout
		#----
		global $comback, $comback_url;
		$comment_id = $this->rs->comment_id;
		$comback_edit_url = "$comback_url&amp;action=edit&amp;id=$comment_id";
		$comback_content = '';
		$comback_author = '';
		$comback_prestyle = '';
		if ($cb = $comback->getComback($comment_id)) {
			$comback_content = '<div class="comback">'.$cb->f('comback_content').'</div>';
			$comback_date = date('d/m/Y H:i',strtotime($cb->f('comback_dt')));
			$comback_author = ($cb->f('user_pseudo') != '' ?
				$cb->f('user_pseudo') :
				$cb->f('user_prenom').' '.$cb->f('user_nom')
			);
			$comback_author = "<tr><td></td><td colspan=\"6\" class=\"comback\">$comback_date - $comback_author</td></tr>";
			$comback_prestyle = ' style="border:none"';
		}
		#----

		$res = '<tr name="line" class="line'.($this->rs->comment_status != 1 ? ' offline' : '').'"'.
		' id="c'.$this->rs->comment_id.'">';
		
		$res .=
		'<td class="nowrap"'.$comback_prestyle.'>'.
		form::checkbox(array('comments[]'),$this->rs->comment_id,'','','',0).'</td>'.
		'<td class="maximal"><a href="'.$post_url.'">'.
		html::escapeHTML($this->rs->post_title).'</a>'.
		' - <a href="'.$comback_edit_url.'">'.__('reply').'</a>'.       # XXX Ajout�
		($this->rs->post_type != 'post' ? ' ('.html::escapeHTML($this->rs->post_type).')' : '').'</td>'.
		'<td class="nowrap">'.dt::dt2str(__('%Y-%m-%d %H:%M'),$this->rs->comment_dt).'</td>'.
		'<td class="nowrap"><a href="'.$author_url.'">'.$comment_author.'</a></td>'.
		'<td class="nowrap">'.($this->rs->comment_trackback ? __('trackback') : __('comment')).'</td>'.
		'<td class="nowrap status">'.$img_status.'</td>'.
		'<td class="nowrap status"><a href="'.$comment_url.'">'.
		'<img src="images/edit-mini.png" alt="" title="'.__('Edit this comment').'" /></a></td>';
		
		$res .= '</tr>';

		# XXX Ajout� : �criture du commentaire (adapt� de _comments.js)
		#----
		$l_comment_site = __('Web site:');
		$l_comment_email =  __('Email:');
		$l_comment_ip = __('IP address:');

		$comment_content = $this->rs->comment_content;
		$comment_site = $this->rs->comment_site;
		$comment_email = $this->rs->comment_email;
		$comment_ip = $this->rs->comment_ip;
		$comment_spam_disp = $this->rs->comment_spam_disp;

		$res .= <<<EOT
<tr id="ce$comment_id" style="display: none"><td$comback_prestyle></td><td colspan="6" style="padding: 0"><div style="padding: 0.5em 1em">$comment_content<p style="margin: 0"><strong>$l_comment_site</strong> $comment_site<br /><strong>$l_comment_email</strong> $comment_email<br /><strong>$l_comment_ip</strong> <a href="comments.php?ip=$comment_ip">$comment_ip</a><br />$comment_spam_disp</p></div>
$comback_content</td></tr>$comback_author
EOT;
		#----

		return $res;
	}
}

?>
