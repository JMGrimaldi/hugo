<?php
if (!defined('DC_RC_PATH')) { return; }

# Fichier pour la classe comback
$GLOBALS['__autoload']['comback'] = dirname(__FILE__).'/class.comback.php';
$GLOBALS['__autoload']['combackList'] = dirname(__FILE__).'/class.combackList.php';
?>
