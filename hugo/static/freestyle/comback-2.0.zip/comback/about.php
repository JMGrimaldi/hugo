<?php
# ComBack for DotClear
# (c)2006-2009 Jihem

echo '<div class="multi-part" id="tab-about" title="'.__('About').'">'.
	'<p>'.__('This is').' ComBack 2.0 '.__('for').' DotClear2.</p>'.
	'<p>'.__('This extension lets you reply to your readers\' comments.').'</p>'.
	'<p>'.__('Help is accessible through the "?" widget on the right.').'</p>'.
	'<p>'.__('Please check').' <a href="http://sphere.dnsalias.org/dotclear2/index.php/post/2009/01/05/ComBack-2%2C-le-retour">'.__('this blog entry').'</a> '.__('for further support, new versions, or for simply telling us how pleased you are with ComBack.').'</p>'.
	'<p>'.__('Enjoy!').' -- Jihem</p>'.
'</div>';
?>
