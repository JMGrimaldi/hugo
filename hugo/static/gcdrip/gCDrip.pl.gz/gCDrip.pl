#!/usr/bin/perl -w
# gCDRip.pl
# Copyright (c) 2003-2004 Jean-Michel Grimaldi
# Author : JM Grimaldi <jm@via.ecp.fr>
#
# This software is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation.
# 
# This software is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
# 
# vim:tabstop=8	

use Gtk;	# load the Gtk-Perl module
use strict;
$| = 1;		# disable print buffering

set_locale Gtk;	# internationalize
init Gtk;	# initialize Gtk-Perl

# Widget creation
#***
# Window
my $window = new Gtk::Window("toplevel");
$window->set_title("gCDrip v1.0");
$window->set_policy(0,0,0);	# size is fixed
$window->border_width(10);

# Vertical packing box
my $vb = new Gtk::VBox(0, 10);	# b_homogeneous, i_spacing
$window->add($vb);

# Album info
#--
my $hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);	# _defaults : (b_expand, b_fill, i_padding) = (1,1,0)

# Artist
$hb->pack_start_defaults(new Gtk::Label('Artist'));
my $artist = new Gtk::Entry();
$hb->pack_start_defaults($artist);

# Genre
$hb->pack_start_defaults(new Gtk::Label('Genre'));
my $genres = &lid3genres_freedb();	# list genres ($genres->{label} = number)
my $genre = new Gtk::Combo();
$genre->set_popdown_strings(sort {$a cmp $b} (keys %$genres));
$genre->set_value_in_list(1,1);		# $must_match, $ok_if_empty
$genre->set_use_arrows_always(1);	# cycle + arrows working if entry not in list
$genre->set_case_sensitive(0);
$genre->entry->set_text('');
$hb->pack_start_defaults($genre);

$hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);

# Album name
$hb->pack_start_defaults(new Gtk::Label('Album'));
my $album = new Gtk::Entry();
$hb->pack_start_defaults($album);

# Year
$hb->pack_start_defaults(new Gtk::Label('Year'));
my $year = new Gtk::Combo();
@_ = localtime; $_ = $_[5]+1900;
$year->set_popdown_strings($_-20..$_);
$year->set_use_arrows_always(1);
$year->entry->set_text('');
$hb->pack_start_defaults($year);

# Comments
$hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);
$hb->pack_start(new Gtk::Label('Comments'),0,0,0);
my $comments = new Gtk::Entry(28);	# 28 chars max
$hb->pack_start_defaults($comments);

# Output params
#--
$vb->pack_start_defaults(new Gtk::HSeparator());

$hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);
my $boutdir = new Gtk::Button("  Output directory  ");
$hb->pack_start($boutdir,0,0,0);
my $outdir = new Gtk::Entry();
$hb->pack_start_defaults($outdir);

$hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);
$hb->pack_start(new Gtk::Label("Output naming"),0,0,0);
my $outnam = new Gtk::Entry();
$outnam->set_text('%p/%a/%n - %t.mp3');
$hb->pack_start_defaults($outnam);

# Tooltip for output naming syntax
my $tlt = new Gtk::Tooltips();
$tlt->set_tip($outnam,<<'EOF');
%p: Performer/Artist
%a: Album
%g: Genre
%t: Track name
%n: Track number
%y: Year
/: Directory
EOF

# Tracks info
#--
$vb->pack_start_defaults(new Gtk::HSeparator());

my ($sectors,$t) = &ltracks();	# list tracks (sectors,duration)
my @titles = ();	# track titles
my $table = new Gtk::Table(scalar @$t, 3, 0);	# i_rows, i_cols, b_homogeneous
$table->set_row_spacings(10);
$table->set_col_spacings(10);
$vb->pack_start_defaults($table);

# Let's arrange the tracks in a table
my $n = 0;
for (@$t) {
	$n++;
	my $track = new Gtk::Label("$n");
	$track->set_alignment(1,.5);
	$table->attach($track, 0,1, $n-1,$n, 'fill','fill',0,0);
	my $length = new Gtk::Label("($_)");
	$length->set_alignment(.5,.5);
	$table->attach($length, 1,2, $n-1,$n, 'fill','fill',0,0);
	my $title = new Gtk::Entry();
#	$title->set_text("Track $n");
	$table->attach_defaults($title, 2,3, $n-1,$n);
	push @titles, $title;
}

# Action buttons
#--
$vb->pack_start_defaults(new Gtk::HSeparator());

$hb = new Gtk::HBox(0, 10);
$vb->pack_start_defaults($hb);

my $babout = new Gtk::Button("   ?   ");
$tlt->set_tip($babout,"About");
$hb->pack_start($babout,0,0,0);

my $bcddb = new Gtk::Button("   CDDB   ");
$tlt->set_tip($bcddb,"Fill form from freedb.org");
$hb->pack_start($bcddb,0,0,0);

my $brip = new Gtk::Button("Rip");
$tlt->set_tip($brip,"Start ripping");
$brip->can_default(1);
$hb->pack_start_defaults($brip);
$brip->grab_default();

# Callbacks registration
#***
$window->signal_connect('delete_event', \&CloseAppWindow);   
$boutdir->signal_connect('clicked', \&DirSel);
$babout->signal_connect('clicked', \&About);
$bcddb->signal_connect('clicked', \&ReadCddb);
$brip->signal_connect('clicked', \&GoRip);

$window->show_all();
main Gtk;

# Sub-functions
#***
# Shared variables
use vars qw($Artist $Genre $Album $Year @Titles $Track $Title);

# Functions
sub CloseAppWindow {
	Gtk->exit(0);
	return 0;
}

sub DirSel {
	my $dialog = new Gtk::FileSelection("Output directory");
	$dialog->ok_button->signal_connect('clicked',\&DirSel_OK,$dialog);
	$dialog->cancel_button->signal_connect('clicked',sub {$dialog->destroy()});
	$dialog->file_list->set_sensitive(0);	# file selection is disabled
	$dialog->set_modal(1);		# events outside the dialog are disabled
	$dialog->show();
}

sub DirSel_OK {
	my ($widget,$dialog) = @_;
	$_ = $dialog->get_filename();
	$outdir->set_text($_);		# update Entry field
	$dialog->destroy();		# close dialog
}

sub About {
	my $dialog = new Gtk::Dialog();
	$dialog->set_title("About");
	$dialog->set_policy(0,0,0);	# size is fixed
	$dialog->border_width(5);

	# Upper part of the dialog
	my $frame = new Gtk::Frame();	# global frame
	$frame->set_shadow_type('etched_in');	# engraved style
	$frame->border_width(10);
	$dialog->vbox->pack_start_defaults($frame);

	my $vb = new Gtk::VBox(0,0);	# stacking inside this frame
	$vb->border_width(2);
	$frame->add($vb);
	
	my $frame2 = new Gtk::Frame();	# button-style title
	$frame2->set_shadow_type('out');
	$vb->pack_start_defaults($frame2);
	my $label = new Gtk::Label("gCDrip 1.0");
	$label->set_usize(0,30);	# fixed vsize
	$frame2->add($label);
	
	$label = new Gtk::Label(<<'EOF');
(c) 2003 Jean-Michel Grimaldi <jm@via.ecp.fr>

CD Ripping interface for Gtk+
Homepage: http://www.via.ecp.fr/~jm/gCDrip.html
EOF
	$label->set_usize(320,0);	# fixed hsize
	$label->set_justify('left');
	$label->set_line_wrap(1);
	$vb->pack_start($label,0,0,10);
	
	# Bottom part of the dialog ('action area')
	# ButtonBox allows us to right-justify buttons
	my $bbox = new Gtk::HButtonBox();
	$bbox->set_layout_default('end');
	$dialog->action_area->pack_start_defaults($bbox);
	
	my $button = new Gtk::Button("OK");
	$button->can_default(1);	# allow it to be default button
	$bbox->add($button);
	$button->grab_default();	# set it at default

	$button->signal_connect('clicked',sub {$dialog->destroy()});
	$dialog->set_modal(1);
	$dialog->show_all();
}

sub GoRip {
	# Get parameters
	$Artist = $artist->get_text();
	$Genre = $genres->{$genre->entry->get_text()};	# undef if no genre
	$Album = $album->get_text();
	$Year = $year->entry->get_text();
	my $Comments = $comments->get_text();
	@Titles = map {$_->get_text()} @titles;
	$Track = $Title = '';	# track number + title
	my $Outdir = $outdir->get_text();
	my $Outnam = $outnam->get_text();

	# Append / to $Outdir if necessary
	$Outdir .= '/' if $Outdir =~ /[^\/]$/;
	
	$_ = $Outnam; /.*\//;		# extract directory part of $Outnam
	$Outnam = $';			# remove it from $Outnam
	$_ = &OutSubs($&); s://+:/:g;	# make substitutions and remove multiple /
	s:^/::;		# 'unroot' dir if there were empty dirnames at the beginning
	$Outdir .= $_;	# append to $Outdir
	print `mkdir -p "$Outdir"` if $Outdir;

	$\ = $/;	# append newline after each print
	my $format = '%.'.length(scalar @$t).'d';
	$n = 0;
	for $Title (@Titles) {	# track title
		$Track = sprintf $format, ++$n;	# track number (uniform width)
		my $fn = &OutSubs($Outnam);	# filename
		$fn =~ tr/:/,/;	# cannot put : in filenames on FAT32

		print "$/* Ripping track $n...";
		print `cd "$Outdir"; cdparanoia -z $n tmp.wav`;

		print "$/* Encoding to $fn...";
		print `cd "$Outdir"; lame -h tmp.wav "$fn"`;

		print "$/* Setting ID3 tags...";
		my $opts = qq(-t "$Title" -T $n -a "$Artist" -A "$Album" -y "$Year" -c "$Comments");
		$opts .= " -g $Genre" if defined $Genre;
		print `cd "$Outdir"; id3 $opts "$fn"`;

		unlink "$Outdir/tmp.wav";
	}
}

sub OutSubs {	# return a string after interpreting %p, %a, etc.
	$_ = $_[0] || return '';
	my %subs = (
		'p' => $Artist,
		'a' => $Album,
		'g' => $Genre,
		't' => $Title,
		'n' => $Track,
		'y' => $Year);
	while (my ($k,$v) = each %subs) {s/\%$k/$v/g}
	return $_;
}

#sub lid3genres {	# List all genres
#	my %g;
#	local *F;
#	open(F, 'id3 -L |');
#	while (<F>) {
#		chop;
#		last unless /(\d+)\: /;	# $1 = genre number / $' = genre label
#		$g{$'} = $1;
#	}
#	close F;
#	return \%g;
#}

sub lid3genres_freedb {	# List only genres recommended on freedb.org, minus data
	my %g = (
		'Blues'		=> 0,
		'Classical'	=> 32,
		'Country'	=> 2,
		'Folk'		=> 80,
		'Jazz'		=> 8,
		'Newage'	=> 10,
		'Reggae'	=> 16,
		'Rock (incl. funk, soul, rap, pop, industrial, metal, etc.)' => 17,
		'Soundtrack (movies, shows)' => 24,
		'Misc' 	=> 12);
	return \%g;
}

sub ltracks {	# List tracks
	my @sectors = ();
	my @t = ();
	local *F;
	open(F, 'cdparanoia -Q 2>&1 |');
	while (<F>) {last if /^=+$/}
	while (<F>) {	# $1 = number of sectors / $2 = duration
		last unless /\d+\.\s*(\d+) \[(\d+\:\d+)/;
		push @sectors, $1;
		push @t, $2;
	}
	close F;
	return (\@sectors,\@t);
}

sub ReadCddb {	# Fill info by reading CDDB info (requires libcddb-get-perl)
	use CDDB_get qw(get_discids get_cddb);
	my %config = ();	# fetching params
	$config{HTTP_PROXY} = $ENV{http_proxy} if $ENV{http_proxy};
	$config{input} = 0;	# no user interaction
	$config{multi} = 0;	# get first possibility
	# Fetch info from freedb.org
	@_ = get_cddb(\%config,get_discids());
	return 0 unless @_ > 1;
	my %cd = @_;

	# Read fetched info
	my $Genre = $cd{cat};
	my $Year = $cd{year};
	my $Artist = $cd{artist};
	my $Album = $cd{title};
	my @Titles = @{$cd{track}} if exists $cd{track};

	# Fill in the form
	if ($Genre) {for (keys %$genres) {
		if (/$Genre/i) {$genre->entry->set_text($_); last}
	}}
	$year->entry->set_text($Year) if defined $Year;
	$artist->set_text($Artist) if $Artist;
	$album->set_text($Album) if $Album;
	for (@titles) {$_->set_text(shift @Titles || '')};

	return 1;
}
