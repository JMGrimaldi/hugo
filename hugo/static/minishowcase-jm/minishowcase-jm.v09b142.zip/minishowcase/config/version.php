<?php
	$version = "v09b142-jm";
	if(isset($_GET['version'])) print(htmlentities($version));
?>
