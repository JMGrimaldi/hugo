<?php

$exif = exif_read_data($_GET["src"], 0, true);
foreach ($exif as $key => $section) {
if($key=="IFD0" or $key=="FILE" or $key=="EXIF" )
foreach ($section as $name => $val) {
if($name == "FileName") $html = "$name:<br />&nbsp; $val<br />";
//if($name == "FileDateTime") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "FileSize") $html .= "$name:<br />&nbsp; $val&nbsp;bytes<br />";
//if($name == "Make") $html .= "Taken With:<br />&nbsp; $val";
if($name == "Model") $html .="Taken With:<br />&nbsp; $val<br />";
//if($name == "Orientation") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ExposureTime") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "FNumber") $html .= "$name:<br />&nbsp; $val<br />";
//if($name == "ExposureProgram") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ISOSpeedRatings") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ShtterSpeedValue") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ApertureValue") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "Flash") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "FocalLength") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ExifImageWidth") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "ExifImageLength") $html .= "$name:<br />&nbsp; $val<br />";
if($name == "FocalLengthIn35mmFilm") $html .= "35mm Equilevant:<br />&nbsp; $val<br />";
if($name == "DateTime") $html .= "Date Taken:<br />&nbsp;".substr($val, 0, 10)."<br />Time Taken:<br />&nbsp;".substr($val, 11)."<br />";

else echo "";
}
}
?>
div = document.getElementById('EXIFinfo');
div.innerHTML = '<?php echo $html; ?>';