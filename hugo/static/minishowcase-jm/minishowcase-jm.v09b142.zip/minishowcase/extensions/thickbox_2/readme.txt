Thickbox 2.1 - One Box To Rule Them All.
By Cody Lindley (http://www.codylindley.com)
Copyright (c) 2006 cody lindley

## Read me ##

This extension is a modified version of the Thickbox 2.1
This extension is released for ENTERTAINING PURPOSES ONLY
I'm in no way responsible for any use, misuse or abuse of it

If you run into trouble, PLEASE CHECK HERE:
http://jquery.com/demo/thickbox
http://www.codylindley.com

This is the original licence of the scripts:

/*
 * Thickbox 2.1 - One Box To Rule Them All.
 * By Cody Lindley (http://www.codylindley.com)
 * Copyright (c) 2006 cody lindley
 * Licensed under the MIT License:
 *   http://www.opensource.org/licenses/mit-license.php
 * Thickbox is built on top of the very light weight jQuery library.
 */