<?php
	$version = "v09b142-jm-1.2";
	if(isset($_GET['version'])) print(htmlentities($version));
?>
