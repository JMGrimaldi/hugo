<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

buffer::str('<h2>'.__('Help').'</h2>');
buffer::str('<h3>'.__('Setup').'</h3>');

buffer::str('<p>'.__('Table dc_comback is automatically created when you first enter the admin interface.').'</p>');
	
$str = '...
&lt;?php while ($comments->fetch()) :
	...
	&lt;blockquote>
	&lt;?php dcCommentContent(); ?>
	&lt;/blockquote>
		
	<strong>&lt;?php dcComback::display(); ?></strong>
&lt;?php endwhile; ?>
...';
		
buffer::str('<p>'.__('To display your replies, add <code>&lt;?php dcComback::display(); ?></code> at the end of the comment-scanning loop, in the <code>post.php</code> of your theme:').'</p>'.
	'<fieldset class="clear"><legend>post.php</legend><pre>'.$str.'</pre></fieldset>');

buffer::str('<h3>'.__('Customization').'</h3>');
buffer::str('<p>'.__('Feel free to modify <code>$comback_display_str</code> in <code>config.php</code> to customize the output.').'</p>');

buffer::str('<h3>'.__('Updating').'</h3>');
buffer::str(__('To install a new version of ComBack, just delete <code>ecrire/tools/comback/</code> directory and install the new ComBack package.'));

buffer::str('<h3>'.__('Advanced functions').'</h3>');

$str = '...
&lt;p class="post-info-co">&lt;a href="&lt;?php dcPostURL(); ?>#co"
title="commentaires pour : &lt;?php dcPostTitle(); ?>">&lt;?php
dcPostNbComments(\'aucun commentaire\',\'un commentaire\',\'%s commentaires\');
?>&lt;/a>
<strong>&lt;?php dcComback::PostNbCombacks(\'\',\'une r&amp;eacute;ponse\',\'%s r&amp;eacute;ponses\',
\'&lt;span>::&lt;/span> \'); ?></strong>
&lt;/p>
...';
buffer::str('<p>'.__('To display the number of replies for a given post, use <code>dcComback::PostNbCombacks()</code> as you do with <code>dcPostNbComments()</code>. There is a 4th optional argument that will prepend the resulting string if it is not empty. For example, in the <code>list.php</code> of your theme:').'</p>'.
	'<fieldset class="clear"><legend>list.php</legend><pre>'.$str.'</pre></fieldset>');

$str = '<strong>&lt;p id="comments-feed">&lt;a class="feed" href="&lt;?php dcComback::rss($post_id); ?>">
Fil des commentaires &amp;amp; r&amp;eacute;ponses de ce billet&lt;/a>&lt;/p></strong>';
buffer::str('<p>'.__('To provide an RSS feed of the comments and replies for a given post, use the following:').'</p>'.
	'<fieldset class="clear"><legend>post.php</legend><pre>'.$str.'</pre></fieldset>');
?>
