<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Ce fichier est adapt� du rss.php de DotClear 1.2.4

# Chemin vers la racine de l'application (si vous changer le fichier de place)
$app_path = '/../../../';

# Si par exemple vous mettez rss.php � la racine de votre site et que DotClear
# se trouve dans /dotclear vous pouvez d�commenter cette ligne :
//$app_path = '/dotclear/';

# NE RIEN CHANGER APRES CETTE LIGNE

$blog_dc_path = dirname(__FILE__).$app_path;

require $blog_dc_path.'/inc/prepend.php';
require $blog_dc_path.'/layout/lib.cache.php';

require $blog_dc_path.'/layout/class.xblog.php';
require $blog_dc_path.'/layout/class.xblogpost.php';
require $blog_dc_path.'/layout/class.xblogcomment.php';

$type = $_GET['type'];
$post = $_GET['post'];

# Cache HTTP
if (dc_http_cache && defined('DC_UPDATE_FILE_W') && DC_UPDATE_FILE_W)
{
	$mod_files = get_included_files();
	$mod_files[] = DC_UPDATE_FILE;
	$mod_files[] = $blog_dc_path.'/conf/dotclear.ini';

	cache::http($mod_files);
}

# Connexion MySQL
$con = new Connection(DB_USER,DB_PASS,DB_HOST,DB_DBASE);

if ($con->error()) { exit; }

# Cr�ation de l'objet de type weblog avec uniquement les billets
# publi�s
$blog = new xblog($con,DB_PREFIX,1,dc_encoding);
$blog->rs_blogpost = 'xblogpost';
$blog->rs_blogcomment = 'xblogcomment';

$blog->setURL('post',util::getHost().dc_blog_url.dc_format_post_url);

# Si type = cb on fait un fil des commentaires & combacks
if (($type == 'cb') && $post) {
	# R�cup�ration des commentaires
	$comments = $blog->getComments($_GET['post'],'DESC');

	# R�cup�ration des combacks
	#---
	# On renomme les champs de dc_comback avec le nom de ceux de dc_comments afin
	# de pouvoir utiliser les m�thodes de la classe xblogcomment
	$t_comback = DB_PREFIX.'comback';
	$strReq = "SELECT c.comment_id, cb.comback_dt comment_dt, cb.comback_content comment_content,
		c.comment_auteur, CONCAT('* ',post_titre) post_titre, p.post_titre_url, p.post_id,
		DATE_FORMAT(p.post_dt,'%d') postday,
		DATE_FORMAT(p.post_dt,'%m') postmonth,
		DATE_FORMAT(p.post_dt,'%Y') postyear
		FROM $t_comback cb, $blog->t_comment c, $blog->t_post p
		WHERE cb.comment_id=c.comment_id AND c.post_id=p.post_id AND p.post_id=$post
		ORDER BY c.comment_dt DESC";
	$combacks = $blog->con->select($strReq,$blog->rs_blogcomment);
	if ($combacks)
		$combacks->setBlog($blog);
	
	$title = dc_blog_name.' - Commentaires &amp; r&eacute;ponses';
	$ts = time();
	$items = $seq = '';
	
	if (!$comments->isEmpty())
	{
		$ts = $comments->getTS();
		
		while(!$comments->EOF()) {
		# On parcourt les commentaires

			if (!$combacks->EOF() && ($combacks->f('comment_id') == $comments->f('comment_id'))) {
			# S'il y a une r�ponse au commentaire c'est elle qu'on met dans le fil
			#---
			# NB : pas besoin d'avancer de plusieurs combacks d'un coup car il y a
			# forc�ment un commentaire pour chaque comback
				$combacks->setField('comment_id','omback'.$combacks->f('comment_id'));
				
				$seq .= $combacks->getRSSSeq();
				$items .= $combacks->getRSSItem(dc_short_feeds);

				$combacks->moveNext();
			} else {
			# S'il n'y a pas de r�ponse on met le comm dans le fil
				$seq .= $comments->getRSSSeq();
				$items .= $comments->getRSSItem(dc_short_feeds);
			}

			$comments->moveNext();
		}
	}
}

# Fermeture de connexion
$con->close();

header('Content-Type: application/rss+xml; charset='.dc_encoding);
echo '<?xml version="1.0" encoding="'.dc_encoding.'" ?>'."\n";
?>
<rdf:RDF
  xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
  xmlns:admin="http://webns.net/mvcb/"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns="http://purl.org/rss/1.0/">

<channel rdf:about="<?php echo util::getHost().dc_blog_url; ?>">
  <title><?php echo $blog->toXML($title); ?></title>
  <description><![CDATA[<?php echo dc_blog_desc; ?>]]></description>
  <link><?php echo util::getHost().dc_blog_url; ?></link>
  <dc:language><?php echo DC_LANG; ?></dc:language>
  <dc:creator></dc:creator>
  <dc:rights></dc:rights>
  <dc:date><?php echo dt::iso8601($ts); ?></dc:date>
  <admin:generatorAgent rdf:resource="http://www.dotclear.net/" />
  
  <sy:updatePeriod>daily</sy:updatePeriod>
  <sy:updateFrequency>1</sy:updateFrequency>
  <sy:updateBase><?php echo dt::iso8601($ts); ?></sy:updateBase>
  
  <items>
  <rdf:Seq>
  <?php echo $seq; ?>
  </rdf:Seq>
  </items>
</channel>

<?php echo $items; ?>

</rdf:RDF>
