<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Adapt� de ecrire/comment.php

require $ecrire_path.'/inc/prepend.php';

$auth->check(1);

include $ecrire_path.'/inc/connexion.php';

$err = '';
$is_editable = false;
$comment_id = '';
$comment_dt = '';
$comment_auteur = '';
$comment_email = '';
$comment_site = '';
$comment_content = '';
$comment_pub = '';
$comment_ip = '';
$user_id = '';
$comback_content = '';

if (!empty($_REQUEST['comment_id']))
{
	$comment = $blog->getComment($_REQUEST['comment_id']);
	
	if ($comment->isEmpty()) {
		$err = '<ul><li>'.__('No comment yet.').'</li></ul>';
	} else {
		$comment_id = $comment->f('comment_id');
		$comment_ldate = dt::str(__('On %A %e %B %Y, %I:%M %p'),$comment->getTS());
		$comment_auteur = $comment->f('comment_auteur');
		$comment_email = $comment->f('comment_email');
		$comment_site = $comment->f('comment_site');
		$comment_content = $comment->f('comment_content');
		$comment_pub = (integer) $comment->f('comment_pub');
		$comment_ip = $comment->f('comment_ip');
		
		$is_editable = true;

		# R�cup�ration de la r�ponse �ventuellement existante
		if ($cb = $comback->getComback($comment_id)) {
			$comback_content = $cb->f('comback_content');
			$comback_user = $cb->f('user_id');

			# Un simple r�dacteur ne peut pas modifier le comback laiss� par quelqu'un d'autre
			if (!($comback_user == $_SESSION['sess_user_id'] || $_SESSION['sess_user_level'] == 9))
				$is_editable = false;
		}
	}
}

# On arr�te tout si le commentaire n'est pas �ditable
if (!$is_editable)
{
	$err = '<ul><li>'.__('You are not allowed to edit this reply').'</li></ul>';
}

# Affichage
#---
if ($is_editable)
{
	# Formatage
	$comment_auteur = htmlspecialchars($comment_auteur);
	$comment_email = htmlspecialchars($comment_email);
	$comment_site = $comment_site ? "http://$comment_site" : '' ;
	$comment_pub = $comment_pub?__('Online'):__('Offline');
	$form_comback_content = form::textArea('comback_content',40,10,htmlspecialchars($comback_content),'','class="max"');

	# Localisation
	$l_Comment = __('Comment');
	$l_From = __('From');
	$l_Email = __('Email');
	$l_Site = __('Site');
	$l_Reply = __('Reply');
	$l_save = __('save');
	$l_delete = __('delete');
	$l_confirm = __('Are you sure you want to delete this reply?');
	$l_Notice = __('Notice');
	$l_HTML = __('This reply has to be in HTML format');

	buffer::str(<<<EOT
	<h3>$l_Comment</h3>

	<p>
	$l_From&nbsp;: $comment_auteur<br />
	$comment_ldate<br />
	$l_Email&nbsp;: $comment_email<br />
	$l_Site&nbsp;: $comment_site<br />
	@IP&nbsp;: $comment_ip</p>
	
	<div class="cadre">$comment_content</div>

	<h3>$l_Reply</h3>

	<form action="$comback_url" method="post">
	$form_comback_content
	<p class="field"><input type="submit" class="submit" name="save" value="$l_save" />&nbsp;
	<input type="submit" class="submit" name="delete" value="$l_delete"
	onclick="return window.confirm('$l_confirm')" />
	<input type="hidden" name="comment_id" id="comment_id" value="$comment_id" /></p>
	</form>

	<p><strong>$l_Notice</strong>&nbsp;: 
	$l_HTML</p>
EOT
);
}
?>
