<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

buffer::str('<h3>'.__('Setup').'</h3>');

buffer::str('<p>'.__('Table dc_comback is automatically created when you first enter the admin interface.').'</p>');
	
$str = '...
&lt;?php while ($comments->fetch()) :
	...
	&lt;blockquote>
	&lt;?php dcCommentContent(); ?>
	&lt;/blockquote>
		
	<strong>&lt;?php dcComback::display(); ?></strong>
&lt;?php endwhile; ?>
...';
		
buffer::str('<p>'.__('To display your replies, add <code>&lt;?php dcComback::display(); ?></code> at the end of the comment-scanning loop, in the <code>post.php</code> of your theme:').'</p>'.
	'<fieldset class="clear"><legend>post.php</legend><pre>'.$str.'</pre></fieldset>');

buffer::str('<p>'.__('Feel free to modify <code>$comback_display_str</code> in <code>config.php</code> to customize the output.').'</p>');


buffer::str('<h3>'.__('Updating').'</h3>');

buffer::str(__('To install a new version of ComBack, just delete <code>ecrire/tools/comback/</code> directory and install the new ComBack package.'));

?>
