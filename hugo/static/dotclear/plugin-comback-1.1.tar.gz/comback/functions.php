<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

require dirname(__FILE__).'/config.php';

# Fonctions c�t� blog
class dcComback {
	# Affichage d'un comback
	function display()
	{
		global $blog, $comback_display_str;
		$table = DB_PREFIX.'comback';
		$com_id = $GLOBALS['comments']->f('comment_id');
		
		$strReq = "select cb.comback_dt, cb.comback_content,
			u.user_pseudo, u.user_prenom, u.user_nom
			from $table cb, $blog->t_user u
			where cb.comment_id = $com_id and cb.user_id = u.user_id";

		# R�cup�ration
		if (!($cb = $blog->con->select($strReq)))
			return false;
		if($cb->isEmpty())
			return true;

		# Formatage
		$ts = strtotime($cb->f('comback_dt'));
		$comback_date = dt::str($blog->date_format, $ts);
		$comback_time = dt::str($blog->time_format, $ts);
		$comback_author = ($cb->f('user_pseudo') != '' ?
	       		$cb->f('user_pseudo') :
			$cb->f('user_prenom').' '.$cb->f('user_nom')
		);
		$comback_content = $cb->f('comback_content');

		# Affichage
		eval('echo <<<EOT
'.$comback_display_str.'
EOT
;');
	}
}
	
?>
