<?php
# ComBack for DotClear
# (c)2006 Jihem
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# Classe de gestion des 'combacks' (r�ponses aux commentaires)
class comback
{
	var $con;	# Connexion � la BD
	var $blog;	# Objet blog
	var $table;	# Nom de la table de stockage des combacks

	# Constructeur
	function comback(&$blog, $prefix)
	{
		$this->con = $blog->con;
		$this->blog = $blog;
		$this->table = $prefix.'comback';
	}
	
	# V�rification des arguments
	function checkArgs($com_id, $user_id, $content)
	{
		if (!$com_id)
			$this->blog->setError(__('No comment ID'), 1000);
		if (!$user_id)
			$this->blog->setError(__('No user ID'), 1000);
		if (!$content)
			$this->blog->setError(__('Empty reply content'), 1000);
		if ($this->blog->error() !== false)
			return false;
		return true;
	}
	
	# Ajout d'un nouveau comback
	function addComback($com_id, $user_id, $content)
	{
		# V�rifications
		if (!$this->checkArgs(trim($com_id), trim($user_id), trim($content)))
			return false;
		
		# Insertion
		$insReq = "insert into $this->table
	       			(comment_id, user_id, comback_dt,
			       	comback_upddt, comback_content)
			values ($com_id, '".$this->con->escapeStr($user_id)."',
		       		SYSDATE(), SYSDATE(),
				'".$this->con->escapeStr($content)."')";

		if (!$this->con->execute($insReq)) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}
		
		$this->blog->triggerMassUpd();
		return true;
	}

	# Mise � jour d'un comback existant
	function updComback($com_id, $user_id, $content)
	{
		# V�rifications
		if (!$this->checkArgs(trim($com_id), trim($user_id), trim($content)))
			return false;

		# Mise � jour
		$updReq = "update $this->table set
				user_id = '".$this->con->escapeStr($user_id)."',
				comback_upddt = SYSDATE(),
				comback_content = '".$this->con->escapeStr($content)."'
			where comment_id = $com_id";

		if (!$this->con->execute($updReq)) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}
		
		$this->blog->triggerMassUpd();
		return true;
	}

	# Suppression d'un comback
	function delComback($com_id)
	{
		$strReq = "select comment_id from $this->table where comment_id = $com_id";
		
		$rs = $this->con->select($strReq);
		if ($rs == false) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}
		if ($rs->isEmpty())
			return false;

		$delReq = "delete from $this->table where comment_id = $com_id";
		if (!$this->con->execute($delReq)) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}
		$this->blog->triggerMassUpd();
		return true;
	}
	
	# Mise � jour si le comback existe, cr�ation sinon, suppression si le contenu est vide
	function saveComback($com_id, $user_id, $content)
	{
		$strReq = "select comment_id from $this->table where comment_id = $com_id";

		$rs = $this->con->select($strReq);
		if ($rs == false) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}

		if ($rs->isEmpty()) {
			if (!trim($content))
				return true;

			return $this->addComback($com_id, $user_id, $content);
		}
		
		if (!trim($content))
			return $this->delComback($com_id);
	
		return $this->updComback($com_id, $user_id, $content);
	}
	
	# R�cup�ration du contenu d'un comback
	function getComback($com_id)
	{
		$strReq = "select cb.comment_id, cb.user_id, u.user_pseudo,
				cb.comback_dt, cb.comback_upddt, cb.comback_content
			from $this->table cb, {$this->blog->t_user} u
			where cb.comment_id = $com_id and cb.user_id = u.user_id";

		$rs = $this->con->select($strReq);
		if ($rs == false) {
			$this->blog->setError('MySQL : '.$this->con->error(), 2000);
			return false;
		}
		if ($rs->isEmpty())
			return false;

		return $rs;
	}
}
?>
